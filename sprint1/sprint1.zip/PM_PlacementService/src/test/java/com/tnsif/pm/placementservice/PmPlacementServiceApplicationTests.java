package com.tnsif.pm.placementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmPlacementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
